import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Input } from '@/components/ui/Input';
import { AuthService } from '@/services/api/AuthService';
import { ROUTES } from '@/constants/routes';
import styles from './SellerRegister.module.css';

/**
 * Merchant Onboarding Feature.
 */
export const SellerRegister: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [formData, setFormData] = useState({
    shopName: '',
    email: '',
    password: '',
    phone: '',
    city: '',
    certification: ''
  });

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await AuthService.registerSeller(formData.email, formData.password, {
        shopName: formData.shopName,
        phone: formData.phone,
        city: formData.city,
        certification: formData.certification
      });
      
      navigate(ROUTES.SELLER_DASHBOARD);
    } catch (err: any) {
      setError(err.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.authCard}>
        <header className={styles.header}>
           <h1 className={styles.title}>Establish Your Merchant Store</h1>
           <p className={styles.subtitle}>Join India's most trusted network of verified pet sellers.</p>
        </header>

        <form className={styles.formGrid} onSubmit={handleRegister}>
          <div className={styles.fullWidth}>
            <Input label="Shop Name" placeholder="e.g. Royal Pets" required value={formData.shopName} onChange={e => setFormData({...formData, shopName: e.target.value})} />
          </div>
          <Input label="Email" type="email" required value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
          <Input label="Password" type="password" required value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} />
          <Input label="Phone" required value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
          <Input label="City" required value={formData.city} onChange={e => setFormData({...formData, city: e.target.value})} />
          <div className={styles.fullWidth}>
            <Input label="Certification ID" required value={formData.certification} onChange={e => setFormData({...formData, certification: e.target.value})} />
          </div>
          {error && <div className={styles.error}>{error}</div>}
          <footer className={styles.footer}>
             <button type="submit" className="button-base button-primary" disabled={loading}>Register</button>
          </footer>
        </form>
      </div>
    </div>
  );
};
