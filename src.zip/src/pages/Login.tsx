import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { ROUTES } from '@/constants/routes';
import { Input } from '@/components/ui/Input';
import styles from './Login.module.css';

/**
 * Platform Authentication & Onboarding Page.
 * Orchestrates login, registration, and role-based onboarding flows
 * through a robust, specialized styling architectural layer.
 * Refactored to eliminate architectural duplication and resolve critical type errors.
 */
const Login: React.FC = () => {
  const [isRegister, setIsRegister] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const navigate = useNavigate();
  const { login, register, updateProfile } = useAuth();

  // Onboarding specific state - Synchronized with centralized User interface
  const [onboardingData, setOnboardingData] = useState({
    displayName: '',
    phone: '',
    role: 'buyer' as 'buyer' | 'seller',
    dateOfBirth: '',
    gender: 'Male',
    city: '',
  });

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isRegister) {
        await register(email, password, onboardingData.role);
        setShowOnboarding(true);
      } else {
        const user = await login(email, password);
        if (user?.role === 'admin') navigate(ROUTES.ADMIN_DASHBOARD);
        else if (user?.role === 'seller') navigate(ROUTES.SELLER_DASHBOARD);
        else navigate(ROUTES.USER_PROFILE);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleOnboardingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateProfile({
        displayName: onboardingData.displayName,
        phone: onboardingData.phone,
        dateOfBirth: onboardingData.dateOfBirth,
        gender: onboardingData.gender,
        addresses: [{
          city: onboardingData.city,
          state: 'Verified Location',
          type: 'Primary',
          name: onboardingData.displayName,
          phone: onboardingData.phone,
          addressLine: onboardingData.city,
          locality: onboardingData.city,
          pincode: '000000'
        }]
      });
      
      if (onboardingData.role === 'seller') navigate(ROUTES.SELLER_DASHBOARD);
      else navigate(ROUTES.USER_PROFILE);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      
      {/* 1. Main Authentication Card */}
      {!showOnboarding && (
        <div className={styles.authCard}>
          <header className={styles.header}>
            <h1 className={styles.title}>{isRegister ? 'Join the Community' : 'Welcome Back'}</h1>
            <p className={styles.subtitle}>The premier marketplace for verified pet listings.</p>
          </header>

          <form className={styles.form} onSubmit={handleAuth}>
            {isRegister && (
               <Input 
                 label="Full Name" 
                 placeholder="John Doe" 
                 required 
                 value={onboardingData.displayName}
                 onChange={e => setOnboardingData({...onboardingData, displayName: e.target.value})}
               />
            )}
            
            <Input 
              label="Email Address" 
              type="email" 
              required 
              value={email} 
              onChange={e => setEmail(e.target.value)} 
            />

            <Input 
              label="Password" 
              type="password" 
              required 
              value={password} 
              onChange={e => setPassword(e.target.value)} 
            />

            {isRegister && (
               <Input 
                 label="Account Role" 
                 as="select" 
                 value={onboardingData.role}
                 onChange={e => setOnboardingData({...onboardingData, role: e.target.value as any})}
               >
                 <option value="buyer">Individual Buyer</option>
                 <option value="seller">Verified Merchant</option>
               </Input>
            )}

            {error && <div className={styles.error}>{error}</div>}

            <button type="submit" className={`${styles.submitBtn} button-base button-primary`} disabled={loading}>
              {loading ? 'Processing...' : (isRegister ? 'Create Account' : 'Sign In')}
            </button>
          </form>

          <footer className={styles.toggle}>
            {isRegister ? 'Already have an account?' : "Don't have an account?"} 
            <span className={styles.toggleBtn} onClick={() => setIsRegister(!isRegister)}>
              {isRegister ? ' Sign In' : ' Sign Up'}
            </span>
          </footer>
        </div>
      )}

      {/* 2. Onboarding Experience (Post-Registration) */}
      {showOnboarding && (
        <div className={styles.onboardingOverlay}>
          <div className={styles.onboardingCard}>
             <header className={styles.header}>
                <h2 className={styles.title}>Complete Your Profile</h2>
                <p className={styles.subtitle}>Help us verify your marketplace identity for a safer community.</p>
             </header>

             <form className={styles.form} onSubmit={handleOnboardingSubmit}>
                <Input 
                  label="Verification Mobile" 
                  placeholder="+91 XXXXX XXXXX" 
                  required 
                  value={onboardingData.phone} 
                  onChange={e => setOnboardingData({...onboardingData, phone: e.target.value})} 
                />
                
                <Input 
                  label="Date of Birth" 
                  type="date" 
                  required 
                  value={onboardingData.dateOfBirth} 
                  onChange={e => setOnboardingData({...onboardingData, dateOfBirth: e.target.value})} 
                />
                
                <Input 
                  label="Location Center" 
                  placeholder="e.g. Mumbai, Maharashtra" 
                  required 
                  value={onboardingData.city} 
                  onChange={e => setOnboardingData({...onboardingData, city: e.target.value})} 
                />

                <button type="submit" className={`${styles.submitBtn} button-base button-primary`} disabled={loading}>
                   {loading ? 'Finalizing Profile...' : 'Enter Marketplace'}
                </button>
             </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Login;
