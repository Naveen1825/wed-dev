import React from 'react';
import { SellerRegister as SellerRegisterFeature } from '@/features/public/SellerRegister';

/**
 * Merchant Registration Page.
 * Orchestrates the seller's onboarding workspace by leveraging the 
 * SellerRegister feature-set to isolate registration logic.
 */
const SellerRegister: React.FC = () => {
  return (
    <div className="seller-register-page">
      <SellerRegisterFeature />
    </div>
  );
};

export default SellerRegister;
